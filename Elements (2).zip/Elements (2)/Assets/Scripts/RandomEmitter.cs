﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandomEmitter : MonoBehaviour {
    public GameObject prefab;
    public float spawnDelay;

    // Use this for initialization
    void Start () {

    }
	

    IEnumerator spawnAtom()
    {
        GameObject newAtom = AtomGen.instance.getRandomAtom();
        newAtom = Instantiate(newAtom, Random.onUnitSphere, Random.rotation);
        yield return new WaitForSeconds(spawnDelay);
    }
}
