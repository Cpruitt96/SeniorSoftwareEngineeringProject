﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class elementLabelControler : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	void OnTriggerEnter(Collider other) {
		
		if(other.gameObject.tag == "Atom")
		{
            other.GetComponent<AtomController>().enableLabel();
		}

	}
	void OnTriggerExit(Collider other) {
			if(other.gameObject.tag == "Atom")
			{
            other.GetComponent<AtomController>().disableLabel();
        }
		}
}
