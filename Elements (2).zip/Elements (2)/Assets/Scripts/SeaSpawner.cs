﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SeaSpawner : MonoBehaviour {

    private GameObject vent;
    public int numVents;
    public float spawnArea;

	void Start () {
        vent = Resources.Load("Vent") as GameObject;
        for (int i = 0; i < numVents; i++)
        {
            Debug.Log("i " + i + " numVents " + numVents);
            Instantiate(vent, new Vector3(Random.Range(0, spawnArea), 0, Random.Range(0, spawnArea)), Quaternion.identity);
        }
    }
	

	void Update () {

	}
}
