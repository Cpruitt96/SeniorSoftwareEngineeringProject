﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class playerMovement : MonoBehaviour {

	public PlayerController playercontroler;
	public Rigidbody rb;
	public GameObject playerMolecule;

	public Text SpeedLabel;
	// Use this for initialization
	void Start () {
		rb = GetComponent<Rigidbody>();
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	void FixedUpdate()
	{
		switch (playercontroler.playerState)
		{
		case PlayerController.PlayerState.PLAY:

			//MOVEMENT

			//WASD
			if (Input.GetKey (KeyCode.W)) {
				rb.AddRelativeForce (new Vector3 (0, 0, playercontroler.energy));
			}
			if (Input.GetKey (KeyCode.S)) {
				rb.AddRelativeForce (new Vector3 (0, 0, playercontroler.energy * -1));
			}
			if (Input.GetKey (KeyCode.D)) {
				rb.AddRelativeForce (new Vector3 (playercontroler.energy, 0, 0));
			}
			if (Input.GetKey (KeyCode.A)) {
				rb.AddRelativeForce (new Vector3 (playercontroler.energy * -1, 0, 0));
			}

			//Up & Down
			if (Input.GetKey (KeyCode.LeftShift)) {
				rb.AddRelativeForce (new Vector3 (0, playercontroler.energy, 0));
			}

			if (Input.GetKey (KeyCode.LeftControl)) {
				rb.AddRelativeForce (new Vector3 (0, playercontroler.energy * -1, 0));
			}

				
			SpeedLabel.text = ("X= " + gameObject.GetComponent<Rigidbody> ().velocity.x + " Y= " + gameObject.GetComponent<Rigidbody> ().velocity.y + " Z= " + gameObject.GetComponent<Rigidbody> ().velocity.z);

		break;
		}
		// rotation
		if (Input.GetKey (KeyCode.LeftArrow)) {
			playerMolecule.transform.Rotate(0,1,0);
		}
		if (Input.GetKey (KeyCode.RightArrow)) {
			playerMolecule.transform.Rotate(0,-1,0);
		}
		if (Input.GetKey (KeyCode.UpArrow)) {
			playerMolecule.transform.Rotate(1,0,0);
		}
		if (Input.GetKey (KeyCode.DownArrow)) {
			playerMolecule.transform.Rotate(-1,0,0);
		}

	}
}
