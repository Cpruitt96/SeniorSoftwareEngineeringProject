﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Molecule : MonoBehaviour {

    public float atomicWeight;

    public void checkWeight()
    {
        atomicWeight = 0;
        Component[] atoms = GetComponentsInChildren<AtomController>();
        foreach (AtomController atom in atoms)
        {
            atomicWeight += atom.atomicWeight;
        }
    }
}
