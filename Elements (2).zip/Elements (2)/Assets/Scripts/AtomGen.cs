﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine.SceneManagement;

public struct Element
{
    public string elementName;
    public string symbol;
    public int numProtons;
    public int numNeutrons;
    public int numElectrons;
    public int weight;
    public Color atomColor;


    public Element(string na, string sym, int p, int n, int e, Color color)
    {
        elementName = na;
        symbol = sym;
        numProtons = p;
        numNeutrons = n;
        numElectrons = e;
        weight = p + n;
        atomColor = color;
    }
}



public class AtomGen : MonoBehaviour {

    public enum ActiveScene { MainMenu, Main}
    public ActiveScene activeScene;
    public int numAtoms = 10;
	public GameObject prefab;
    public float spawnRadius;

    public List<GameObject> atoms = new List<GameObject>();

    private List<Element> elements;

    public static AtomGen instance;

    public int maxWeight;

    public int playerWeight;

    public byte alpha = 40;

    public static int count = 0;

    public List<int> weights = new List<int>();

    void Start() 
	{
        instance = this;


        //Periodic Elements
        elements = new List<Element>();
        //http://www.elementalmatter.info/number-protons-neutrons.htm
		elements.Add(new Element("Hydrogen", "H", 1, 0, 1, new Color32(255, 255, 255, alpha)));
		elements.Add(new Element("Helium", "He", 2, 2, 2, new Color32(0, 255, 255, alpha)));
		elements.Add(new Element("Lithium", "Li", 3, 4, 3, new Color32(238, 130, 238, alpha)));//violet
		elements.Add(new Element("Beryllium", "Be", 4, 5, 4, new Color32(0, 100, 0, alpha)));//dark green
		elements.Add(new Element("Boron", "B", 5, 6, 5, new Color32(255, 218, 185, alpha)));//peach
		elements.Add(new Element("Carbon", "C", 6, 6, 6, new Color32(0, 0, 0, alpha)));
		elements.Add(new Element("Nitrogen", "N", 7, 7, 7, new Color32(0, 0, 255, alpha)));
		elements.Add(new Element("Oxygen", "O", 8, 8, 8, new Color32(255, 0, 0, alpha)));
		elements.Add(new Element("Fluorine", "F", 9, 9, 9, new Color32(0, 255, 0, alpha)));
		elements.Add(new Element("Neon", "Ne", 10, 10, 10, new Color32(0, 255, 255, alpha)));

		elements.Add(new Element("Sodium", "Na", 11, 12, 11, new Color32(238, 130, 238, alpha)));//violey
		elements.Add(new Element("Magnesium", "Hmg", 12, 12, 12, new Color32(0, 100, 0, alpha)));//dark green
		elements.Add(new Element("Aluminium", "Al", 13, 14, 13, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Silicon", "Si", 14, 14, 14, new Color32(255, 218, 185, alpha)));//peach
		elements.Add(new Element("Phosphorus", "P", 15, 16, 15, new Color32(255, 69, 0,alpha)));//orange
		elements.Add(new Element("Sulfur", "S", 16, 16, 16, new Color32(255, 255, 0,alpha)));//yellow
		elements.Add(new Element("Chlorine", "Cl", 17, 18, 17,new Color32(0, 255, 0,alpha)));//green
		elements.Add(new Element("Argon", "Ar", 18, 22, 18,  new Color32(0, 255, 255, alpha)));//cyan
		elements.Add(new Element("Potassium", "K", 19, 21, 19, new Color32(238, 130, 238, alpha)));//violet
		elements.Add(new Element("Calcium", "Ca", 20, 20, 20, new Color32(0, 100, 0, alpha)));//dark green

		elements.Add(new Element("Scandium", "Sc", 21, 24, 21, new Color32(255, 218, 185, alpha)));//peach
		elements.Add(new Element("Titanium", "Ti", 22, 26, 22, new Color32(128, 128, 128, alpha)));//gray
		elements.Add(new Element("Vanadium", "V", 23, 28, 23, new Color32(255, 218, 185, alpha)));//peach
		elements.Add(new Element("Chromium", "Cr", 24, 28, 24, new Color32(255, 218, 185, alpha)));//peach
		elements.Add(new Element("Manganese", "Mn", 25, 30, 25, new Color32(255, 218, 185, alpha)));//peach
		elements.Add(new Element("Iron", "Fe", 26, 30, 26, new Color32(255, 218, 185, alpha)));//peach
		elements.Add(new Element("Cobalt", "Co", 27, 31, 27, new Color32(255, 218, 185, alpha)));//peach
		elements.Add(new Element("Nickel", "Ni", 28, 30, 28, new Color32(255, 218, 185, alpha)));//peach
		elements.Add(new Element("Copper", "Cu", 29, 35, 29, new Color32(255, 218, 185, alpha)));//peach
		elements.Add(new Element("Zinc", "Zn", 30, 35, 30,new Color32(255, 218, 185, alpha)));//peach

		elements.Add(new Element("Gallium", "Ga", 31, 39, 31, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Germanium", "Ge", 32, 41, 32, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Arsenic", "As", 33, 28, 42, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Selenium", "Se", 34, 45, 34, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Bromine", "Br", 35, 45, 35, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Krypton", "Kr", 36, 48, 36,  new Color32(0, 255, 255, alpha)));//cyan
		elements.Add(new Element("Rubidium ", "Rb", 37, 48, 37, new Color32(238, 130, 238, alpha)));//violet
		elements.Add(new Element("Strontium", "Sr", 38, 50, 38, new Color32(0, 100, 0, alpha)));//dark green
		elements.Add(new Element("Yttrium", "Y", 39, 50, 39, new Color32(255, 218, 185, alpha)));//peach
		elements.Add(new Element("Zirconium", "Zr", 40, 51, 40, new Color32(255, 218, 185, alpha)));//peach

		elements.Add(new Element("Niobium", "Nb", 41, 52, 41, new Color32(255, 218, 185, alpha)));//peach
		elements.Add(new Element("Molybdenum", "Mo", 42, 54, 42, new Color32(255, 218, 185, alpha)));//peach
		elements.Add(new Element("Technetium", "Tc", 43, 55, 43, new Color32(255, 218, 185, alpha)));//peach
		elements.Add(new Element("Ruthenium", "Ru", 44, 57, 44, new Color32(255, 218, 185, alpha)));//peach
		elements.Add(new Element("Rhodium", "Rh", 45, 58, 45, new Color32(255, 218, 185, alpha)));//peach
		elements.Add(new Element("Palladium", "Pd", 46, 60, 46, new Color32(255, 218, 185, alpha)));//peach
		elements.Add(new Element("Silver", "Ag", 47, 61, 47, new Color32(255, 218, 185, alpha)));//peach
		elements.Add(new Element("Cadmium", "Cd", 48, 64, 48, new Color32(255, 218, 185, alpha)));//peach
		elements.Add(new Element("Indium", "In", 49, 66, 49, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Tin", "Sn", 50, 69, 50, new Color32(255, 20, 147, alpha)));//pink

		elements.Add(new Element("Antimony", "Sb", 51, 71, 51, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Tellurium", "Te", 52, 76, 52, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Iodine", "I", 53, 74, 53, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Xenon", "Xe", 54, 77, 54,  new Color32(0, 255, 255, alpha)));//cyan
		elements.Add(new Element("Cesium", "Cs", 55, 78, 55, new Color32(238, 130, 238, alpha)));//violet
		elements.Add(new Element("Barium", "Ba", 56, 81, 56, new Color32(0, 100, 0, alpha)));//dark green
		elements.Add(new Element("Lanthanum", "La", 57, 82, 57, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Cerium", "Ce", 58, 82, 5, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Praseodymium", "Pr", 59, 82, 59, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Neodymium", "Nd", 60, 84, 60, new Color32(255, 20, 147, alpha)));//pink

		elements.Add(new Element("Promethium", "Pm", 61, 84, 61, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Samarium", "Sm", 62, 88, 62, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Europium", "Eu", 63, 89, 63, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Gadolinium", "Gd", 64, 93, 64, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Terbium", "Tb", 65, 94, 65, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Dysprosium", "Dy", 66, 97, 66, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Holmium", "Ho", 67, 98, 67, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Erbium", "Er", 68, 99, 68, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Thulium", "Tm", 69, 100, 69, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Ytterbium", "Yb", 70, 103, 70, new Color32(255, 20, 147, alpha)));//pink

		elements.Add(new Element("Lutetium", "Lu", 71, 104, 71, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Hafnium", "Hf", 72, 106, 72, new Color32(255, 218, 185, alpha)));//peach
		elements.Add(new Element("Tantalum", "Ta", 73, 108, 73, new Color32(255, 218, 185, alpha)));//peach
		elements.Add(new Element("Tungsten", "W", 74, 110, 74, new Color32(255, 218, 185, alpha)));//peach
		elements.Add(new Element("Rhenium", "Re", 75, 111, 75, new Color32(255, 218, 185, alpha)));//peach
		elements.Add(new Element("Osmium", "Os", 76, 114, 76, new Color32(255, 218, 185, alpha)));//peach
		elements.Add(new Element("Iridium", "Ir", 77, 115, 77, new Color32(255, 218, 185, alpha)));//peach
		elements.Add(new Element("Platinum", "Pt", 78, 117, 78, new Color32(255, 218, 185, alpha)));//peach
		elements.Add(new Element("Gold", "Au", 79, 118, 79, new Color32(255, 218, 185, alpha)));//peach
		elements.Add(new Element("Mercury", "Hg", 80, 121, 80, new Color32(255, 218, 185, alpha)));//peach

		elements.Add(new Element("Thallium", "Tl", 81, 123, 81, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Lead", "Pb", 82, 125, 82, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Bismuth", "Bi", 83, 126, 83, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Polonium", "Po", 84, 125, 84, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Astatine", "At", 85, 125, 85, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Radon", "Rn", 86, 136, 86,  new Color32(0, 255, 255, alpha)));//cyan
		elements.Add(new Element("Francium", "Fr", 87, 136, 87, new Color32(238, 130, 238, alpha)));//violet
		elements.Add(new Element("Radium", "Ra", 88, 138, 88, new Color32(0, 100, 0, alpha)));//dark green
		elements.Add(new Element("Actinium", "Ac", 89, 138, 89, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Thorium", "Th", 90, 142, 90, new Color32(255, 20, 147, alpha)));//pink

		elements.Add(new Element("Protactinium", "Pa", 91, 140, 91, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Uranium", "U", 92, 146, 92, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Neptunium", "Np", 93, 144, 93, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Plutonium", "Pu", 94, 150, 94, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Americium", "Am", 95, 148, 95, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Curium", "Cm", 96, 151, 96, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Berkelium", "Bk", 97, 150, 97, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Californium", "Cf", 98, 153, 98, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Einsteinium", "Es", 99, 153, 99, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Fermium", "Fm", 100, 157, 100, new Color32(255, 20, 147, alpha)));//pink

		elements.Add(new Element("Mendelevium", "Md", 101, 157, 101, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Nobelium", "No", 102, 157, 102, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Lawrencium", "Lr", 103, 159, 103, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Rutherfordium", "Rf", 104, 157, 104, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Dubnium", "Db", 105, 157, 105, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Seaborgium", "Sg", 106, 157, 106, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Bohrium", "Bh", 107, 157, 107, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Hassium", "Hs", 108, 161, 108, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Meitnerium", "Mt", 109, 159, 109, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Darmstadtium", "Ds", 110, 162, 110, new Color32(255, 20, 147, alpha)));//pink

		elements.Add(new Element("Roentgenium", "Rg", 111, 162, 111, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Copernicum", "Cn", 112, 165, 112, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Nihonium", "Nh", 113, 173, 113, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Flerovium", "Fl", 114, 175, 114, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Moscovium", "Mc", 115, 173, 115, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Livermorium", "Lv", 116, 176, 116, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Tennessine", "Ts", 117, 175, 117, new Color32(255, 20, 147, alpha)));//pink
		elements.Add(new Element("Oganesson", "Og", 118, 175, 118, new Color32(0, 255, 255, alpha)));//cyan
		elements.Add(new Element("Obondium", "Ob", 119, 178, 119, new Color32(255, 20, 147, alpha)));//pink

        if (SceneManager.GetActiveScene().Equals(SceneManager.GetSceneByName("MainMenu")))
            activeScene = ActiveScene.MainMenu;
        else if (SceneManager.GetActiveScene().Equals(SceneManager.GetSceneByName("Main")))
            activeScene = ActiveScene.Main;

        foreach (Element element in elements)
        {
            weights.Add(element.weight);
        }
        switch (activeScene)
        {
            case ActiveScene.MainMenu:
                spawnRandAtoms();
                break;
            case ActiveScene.Main:
                StartCoroutine(spawnAtoms());
                break;
        }
        
        
	}



    //Spawn numAtoms atoms as random elements
    void spawnRandAtoms()
    {
        for (int i = 0; i < numAtoms; i++)
        {
            GameObject newAtom = getRandomAtom();

            newAtom = Instantiate(newAtom, Random.onUnitSphere * spawnRadius, Random.rotation);
            newAtom.transform.GetChild(1).GetComponent<Renderer>().material.color = new Color((newAtom.GetComponent<AtomController>().atomicWeight * 2), 0, 0, 0.1f);
        }
    }


    //Spawn atoms starting with atoms with the lowest weight and spawn increasingly heaver atoms as the player's weight increases
    public IEnumerator spawnAtoms()
    {
        maxWeight = 3;
        playerWeight = 120;
        while (maxWeight != 120)
        {
            if(count < numAtoms)
            {
//                for (int i = 0; i < numAtoms; i++)
//                {
                    GameObject newAtom = getAtom(weights[UnityEngine.Random.Range(0, maxWeight)]);
                    newAtom = Instantiate(newAtom, Random.onUnitSphere * spawnRadius, Random.rotation);
                    if (SceneManager.GetActiveScene().Equals(SceneManager.GetSceneByName("Main")))
                    {
                        if (GameObject.Find("Player Element").GetComponent<AtomController>().atomicWeight >= playerWeight + maxWeight)
                        {
                            playerWeight += maxWeight;
                            maxWeight += 3;
                        }
                       
                    }
                    count += 1;
                //}
            }
            yield return new WaitForSeconds(.1f);
        }
    }



    //Return an element from list based by weight
    public Element getElement(int aWeight)
    {
        //Find the element with the matching weight
        foreach (Element element in elements)
        {
            if (element.weight == aWeight)
            {
                return element;
            }
        }
        //Default to nearest element if not found
        for(int i = 0; i < elements.Count; i++)
        {
            foreach (Element element in elements)
            {
                if (Enumerable.Range(element.weight - i, element.weight + i).Contains(aWeight)) 
                {
                    return element;
                }
            }
        }
        return elements[elements.Count - 1];
    }

    //Return a randomly chosen element from list
    public Element getRandomElement()
    {
        return elements[Random.Range(0, elements.Count)];
    }



    //Return an atom GameObject with appropriate element properties based on weight
    public GameObject getAtom(int weight)
    {
        //Grab prefab
        GameObject newAtom = prefab;
        //Get element
        Element element = getElement(weight);

        //Assign element's qualities to atom
        newAtom.GetComponent<AtomController>().setupAtom(element.elementName, element.symbol, element.numProtons, element.numNeutrons, element.numElectrons, element.atomColor);

        newAtom.name = "Atom";

        return newAtom;
    }

    //Return a random atom GameObject with a randomly chosen element's properties
    public GameObject getRandomAtom()
    {
        //Grab prefab
        GameObject newAtom = prefab;
        //Get a random element
        Element element = getRandomElement();

        //Assign element's qualities to atom
        newAtom.GetComponent<AtomController>().setupAtom(element.elementName, element.symbol, element.numProtons, element.numNeutrons, element.numElectrons, element.atomColor);

        newAtom.name = "Atom";

        return newAtom;
    }



    public Element getNextElement(AtomController baseElement)
    {
        foreach (Element element in elements)
        {
            if(element.elementName == baseElement.elementName)
            {
                return elements[elements.IndexOf(element) + 1];
            }
        }
        return elements[elements.Count-1];
    }

    public Element getPreviousElement(AtomController baseElement)
    {
        foreach (Element element in elements)
        {
            if (element.elementName == baseElement.elementName)
            {
                return elements[elements.IndexOf(element) - 1];
            }
        }
        return elements[elements.Count - 1];
    }

    //Return an atom GameObject with appropriate element properties based on weight
    public GameObject getNextAtom(AtomController baseElement)
    {
        //Grab prefab
        GameObject newAtom = prefab;
        //Get element
        Element element = getNextElement(baseElement);

        //Assign element's qualities to atom
        newAtom.GetComponent<AtomController>().setupAtom(element.elementName, element.symbol, element.numProtons, element.numNeutrons, element.numElectrons, element.atomColor);

        newAtom.name = "Atom";

        return newAtom;
    }

    public GameObject getPreviousAtom(AtomController baseElement)
    {
        //Grab prefab
        GameObject newAtom = prefab;
        //Get element
        Element element = getPreviousElement(baseElement);

        //Assign element's qualities to atom
        newAtom.GetComponent<AtomController>().setupAtom(element.elementName, element.symbol, element.numProtons, element.numNeutrons, element.numElectrons, element.atomColor);

        newAtom.name = "Atom";

        return newAtom;
    }
}
