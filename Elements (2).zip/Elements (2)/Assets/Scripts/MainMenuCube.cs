﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainMenuCube : MonoBehaviour {
    public float size;

    private GameObject plane;

    void Start()
    {
        plane = Resources.Load("MainMenuPlane") as GameObject;

        //z+
        GameObject zPlusWall = Instantiate(plane, new Vector3(0, 0, size / 2), Quaternion.identity);
        zPlusWall.transform.localScale = new Vector3(size / 10, 1, size / 10);
        zPlusWall.transform.Rotate(-90, 0, 0);


        //z-
        GameObject zMinusWall = Instantiate(plane, new Vector3(0, 0, -size / 2), Quaternion.identity);
        zMinusWall.transform.localScale = new Vector3(size / 10, 1, size / 10);
        zMinusWall.transform.Rotate(90, 0, 0);


        //y+
        GameObject yPlusWall = Instantiate(plane, new Vector3(0, size / 2, 0), Quaternion.identity);
        yPlusWall.transform.localScale = new Vector3(size / 10, 1, size / 10);
        yPlusWall.transform.Rotate(180, 0, 0);


        //y-
        GameObject yMinusWall = Instantiate(plane, new Vector3(0, -size / 2, 0), Quaternion.identity);
        yMinusWall.transform.localScale = new Vector3(size / 10, 1, size / 10);
        yMinusWall.transform.Rotate(0, 0, 0);

        //x+
        GameObject xPlusWall = Instantiate(plane, new Vector3(size / 2, 0, 0), Quaternion.identity);
        xPlusWall.transform.localScale = new Vector3(size / 10, 1, size / 10);
        xPlusWall.transform.Rotate(0, 0, 90);

        //x-
        GameObject xMinusWall = Instantiate(plane, new Vector3(-size / 2, 0, 0), Quaternion.identity);
        xMinusWall.transform.localScale = new Vector3(size / 10, 1, size / 10);
        xMinusWall.transform.Rotate(0, 0, -90);
    }
}
