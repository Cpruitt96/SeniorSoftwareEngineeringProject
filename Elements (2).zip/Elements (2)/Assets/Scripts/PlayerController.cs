﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour {

    public static PlayerController instance;

    public enum PlayerState {PLAY, EDIT, TO_PLAY, TO_EDIT, PAUSED}
    public PlayerState playerState;
	public GameObject playersMovementControler;
   	public Rigidbody rb;
    public float speed;

    public float energy;
    public float maxEnergy;
    public Text energyValue;
    public int fusionEnergyReq;

    public List<GameObject> selectedAtoms;

    public GameObject atomPrefab;
	public Text editModeDescription;
	public GameObject editDescriptionHolder;
	public Text SpeedLabel;
	public GameObject playerElementGameObject;
	public AtomController playerElement;
	public GameObject theCamera;
	float rotationY = 0F;
	public float minimumY = -60F;
	public float maximumY = 60F;
	//Vector3 cameraLocation;
	//Quaternion cameraRotation;

	//public pauseMenuController pauseControler;

    void Start () {
        instance = this;

        playerState = PlayerState.TO_PLAY;

        rb = GetComponent<Rigidbody>();

        atomPrefab = Resources.Load("Atom") as GameObject;

        modifyEnergy(10);

        selectedAtoms = new List<GameObject>();

		editDescriptionHolder.SetActive (false);

		FixedJoint myJoint = gameObject.AddComponent<FixedJoint>();

		//Give joint an appropriate break force based on each bonded atom***********************************************************************************************
		//myJoint.breakForce = jointStrength;
		myJoint.connectedBody = playerElementGameObject.GetComponent<Rigidbody>();
		myJoint.enablePreprocessing = false;
		myJoint.anchor = new Vector3(0, 0, 0);
		myJoint.connectedAnchor = transform.InverseTransformPoint(playerElementGameObject.transform.position);

		//Target side
		FixedJoint targetsJoint = playerElementGameObject.AddComponent<FixedJoint>();

		//Give joint an appropriate break force based on each bonded atom
		//targetsJoint.breakForce = jointStrength;
		targetsJoint.connectedBody = GetComponent<Rigidbody>();
		targetsJoint.enablePreprocessing = false;
		targetsJoint.anchor = new Vector3(0, 0, 0);
		targetsJoint.connectedAnchor = playerElementGameObject.transform.InverseTransformPoint(transform.position);
    }



    private void Update()
    {
        switch (playerState)
        {
            case PlayerState.PLAY:
                //Switch mode
                if (Input.GetKeyDown(KeyCode.F1))
                    playerState = PlayerState.TO_EDIT;
                break;


            case PlayerState.EDIT:

                //Switch mode
                if (Input.GetKeyDown(KeyCode.F1))
                    playerState = PlayerState.TO_PLAY;


                if (Input.GetKeyDown(KeyCode.Space))
                    fuse();
                break;


            case PlayerState.TO_PLAY:
                //Hide mouse, enable mouse look
                Cursor.visible = false;
				playersMovementControler.transform.GetComponent<MouseLook>().enabled = true;
                editDescriptionHolder.SetActive(false);
				//Time.timeScale = 1f;
				//pauseControler.isPaused = true;
                //Return selected atoms to their normal color and remove them from lists
                foreach (GameObject selection in selectedAtoms)
                {
                    selection.GetComponent<AtomController>().setColor();
                }
                selectedAtoms.Clear();

                playerState = PlayerState.PLAY;
                break;


			case PlayerState.TO_EDIT:
		                //Reveal mouse, disable mouse look
				Cursor.visible = true;
		                //Reset mouse position here
				playersMovementControler.transform.GetComponent<MouseLook> ().enabled = false;
						//Time.timeScale = 0f;
						//pauseControler.isPaused = true;
						
				editDescriptionHolder.SetActive (true);

				//cameraLocation = theCamera.transform.position;
				//cameraRotation = theCamera.transform.rotation;
                playerState = PlayerState.EDIT;
                break;

			case PlayerState.PAUSED:
				Cursor.visible = true;
				playersMovementControler.transform.GetComponent<MouseLook> ().enabled = false;
				break;
        }

        
    }
//	private void OnCollisionEnter(Collision collision)
//	{
//		if(collision.gameObject.tag == "Atom")
//		{
//			playerElement.bond(collision.gameObject);
//		}
//		if (gameObject.tag == "Player") {	
//			//Debug.Log ("player colision");
//
//		}
//	}



    void FixedUpdate()
    {
        switch (playerState)
        {
		case PlayerState.PLAY:

                //MOVEMENT

                //WASD
			if (Input.GetKey (KeyCode.W))
				rb.AddRelativeForce (new Vector3 (0, 0, energy));

			if (Input.GetKey (KeyCode.S))
				rb.AddRelativeForce (new Vector3 (0, 0, energy * -1));

			if (Input.GetKey (KeyCode.D))
				rb.AddRelativeForce (new Vector3 (energy, 0, 0));

			if (Input.GetKey (KeyCode.A))
				rb.AddRelativeForce (new Vector3 (energy * -1, 0, 0));


                //Up & Down
			if (Input.GetKey (KeyCode.LeftShift))
				rb.AddRelativeForce (new Vector3 (0, energy, 0));

			if (Input.GetKey (KeyCode.LeftControl))
				rb.AddRelativeForce (new Vector3 (0, energy * -1, 0));
			SpeedLabel.text = ("X= " + gameObject.GetComponent<Rigidbody> ().velocity.x + " Y= " + gameObject.GetComponent<Rigidbody> ().velocity.y + " Z= " + gameObject.GetComponent<Rigidbody> ().velocity.z);
			// rotation
			if (Input.GetKey (KeyCode.LeftArrow)) {
				playerElementGameObject.transform.Rotate(0,1,0);
			}
			if (Input.GetKey (KeyCode.RightArrow)) {
				playerElementGameObject.transform.Rotate(0,-1,0);
			}
			if (Input.GetKey (KeyCode.UpArrow)) {
				playerElementGameObject.transform.Rotate(1,0,0);
			}
			if (Input.GetKey (KeyCode.DownArrow)) {
				playerElementGameObject.transform.Rotate(-1,0,0);
			}
			if (Input.GetKey (KeyCode.Period)) {
				playerElementGameObject.transform.Rotate(0,0,1);

			}
			if (Input.GetKey (KeyCode.Slash)) {
				playerElementGameObject.transform.Rotate(0,0,-1);

			}
            break;
		case PlayerState.EDIT:
			
			if (Input.GetKey (KeyCode.LeftArrow)) {
				transform.Rotate(0,1,0);
			}
			if (Input.GetKey (KeyCode.RightArrow)) {
				transform.Rotate(0,-1,0);
			}
			if (Input.GetKey (KeyCode.UpArrow)) {
				transform.Rotate(1,0,0);

			}
			if (Input.GetKey (KeyCode.DownArrow)) {
				transform.Rotate(-1,0,0);

			}
			if (Input.GetKey (KeyCode.Period)) {
				transform.Rotate(0,0,1);

			}
			if (Input.GetKey (KeyCode.Slash)) {
				transform.Rotate(0,0,-1);

			}
			break;
       	}

		//zoom in zoom out
		if ((Input.GetKey (KeyCode.Return))) {
			
				theCamera.transform.Translate (0, 0, 1);

		}
		if ((Input.GetKey (KeyCode.RightShift))) {
			theCamera.transform.Translate(0, 0, - 1);
		}
    }



    //Adds an atom to the selected list if the conditions are right. Returns whether the atom was selected.
    public bool selectAtom(GameObject atom)
    {

        //If already selected, deselect
        if (selectedAtoms.Contains(atom))
        {
            atom.GetComponent<AtomController>().setColor();
            selectedAtoms.Remove(atom);
            return false;
        }


        //Checks how many atoms are selected and acts appropriately
        switch (selectedAtoms.Count)
        {
            case 0:
                //If there are no current selections

                //Add atom to selected
                selectedAtoms.Add(atom);

                //Change color to green to indicate selected
                atom.transform.GetChild(1).GetComponent<Renderer>().material.color = Color.green;

                return true;
            case 1:
                //If the stored selection has a joint to the new selection
                if(selectedAtoms[0].GetComponent<AtomController>().bondedAtoms.Contains(atom))
                {
                    //Add atom to selected
                    selectedAtoms.Add(atom);

                    //Change color to green to indicate selected
                    atom.transform.GetChild(1).GetComponent<Renderer>().material.color = Color.green;

                    return true;
                }
                return false;
        }
        return false;
    }



    void fuse()
    {
        //Check for energy requirement and two atoms
        if (energy > fusionEnergyReq && selectedAtoms.Count == 2 && selectedAtoms[0].GetComponent<AtomController>().atomicWeight == selectedAtoms[1].GetComponent<AtomController>().atomicWeight)
        {
            //Win Condition
            if(selectedAtoms[0].GetComponent<AtomController>().elementName == "Obondium")
            {
                GameObject.Find("WinScreen").SetActive(true);
            }

            modifyEnergy(-fusionEnergyReq);

            //Gather the bonded atoms
            List<GameObject> combinedBondedAtoms = new List<GameObject>();
            AtomController atomOne = selectedAtoms[0].GetComponent<AtomController>();
            AtomController atomTwo = selectedAtoms[1].GetComponent<AtomController>();

            //Get all the bonded atoms in atom1
            foreach (GameObject bondedAtom in atomOne.bondedAtoms)
            {
                combinedBondedAtoms.Add(bondedAtom);
            }

            //Get all the bonded atoms in atom2
            foreach (GameObject bondedAtom in atomTwo.bondedAtoms)
            {
                combinedBondedAtoms.Add(bondedAtom);
            };

            combinedBondedAtoms.Remove(atomOne.gameObject);
            combinedBondedAtoms.Remove(atomTwo.gameObject);

            //Get the fused atom/element
            GameObject productAtom = AtomGen.instance.getNextAtom(atomOne);

            //Get the position between the two
            Vector3 productPosition = (selectedAtoms[0].transform.position + selectedAtoms[1].transform.position) / 2;

            //Destroy reactants and remove all of their joints as they're no longer needed
            atomOne.unbond();
            atomTwo.unbond();

            //Clear lists
            selectedAtoms.Clear();

            //Create product
            GameObject theAtom = Instantiate(productAtom, productPosition, Quaternion.identity);

            //Bond targets to new atom
            foreach (GameObject target in combinedBondedAtoms)
            {
                if(target != null)
                {
                    target.GetComponent<AtomController>().bond(theAtom);
                }
            }
			theAtom.GetComponent<AtomController> ().labelFlag = true;
            AtomGen.count -= 1;
        }
        else
        {
            //Need 'more energy' indicator****************************************************************************************
        }
    }

    //Add or subtract energy
    public void modifyEnergy(float energyAmount)
    {
        if(energy + energyAmount < maxEnergy)
        {
            energy += energyAmount;
            energyValue.text = "Energy: " + energy.ToString();
        }
        else
        {
            energy = maxEnergy;
        }
        
    }
}
