﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class HeatSystem : MonoBehaviour {

    public static Action<float> heat;
    public float heatDelay;
    public float heatAmount;


	void Start () {
        StartCoroutine(periodicHeat());
	}
	
	void Update () {
		
	}

    IEnumerator periodicHeat()
    {
        while (true)
        {
            yield return new WaitForSeconds(heatDelay);
            heat(heatAmount);
        }
    }
}
