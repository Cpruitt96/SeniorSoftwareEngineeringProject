﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreTracker : MonoBehaviour {
	public Text score;
	public GameObject player;
    public static ScoreTracker instance;

	void Start () {
        instance = this;
		score.text = "Score:  "+"0";
	}

    public void updateScore()
    {
        score.text = "Score:  " + player.transform.parent.GetComponent<Molecule>().atomicWeight.ToString();
    }
}
