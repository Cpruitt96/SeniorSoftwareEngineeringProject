﻿using UnityEngine;
using System.Collections.Generic;

public struct MenuElement
{
    public string elementName;
    public string symbol;
    public int numProtons;
    public int numNeutrons;
    public int numElectrons;
    public int weight;
    //public Color color;

    public MenuElement(string na, string sym, int p, int n, int e)
    {
        elementName = na;
        symbol = sym;
        numProtons = p;
        numNeutrons = n;
        numElectrons = e;
        weight = p + n;
    }
}



public class MainMenuAtomGen : MonoBehaviour {

	public int numAtoms = 10;
	public GameObject prefab;
    public float spawnRadius;

    public List<GameObject> atoms = new List<GameObject>();

    private List<Element> elements;

    public static MainMenuAtomGen instance;

    void Start() 
	{
        instance = this;


        //Periodic Elements
        elements = new List<Element>();
        //http://www.elementalmatter.info/number-protons-neutrons.htm
        //elements.Add(new Element("Hydrogen", "H", 1, 0, 1));
        //elements.Add(new Element("Helium", "He", 2, 2, 2));
        //elements.Add(new Element("Lithium", "Li", 3, 4, 3));
        //elements.Add(new Element("Beryllium ", "Be", 4, 5, 4));
        //elements.Add(new Element("Boron", "B", 5, 6, 5));
        //elements.Add(new Element("Carbon", "C", 6, 6, 6));
        //elements.Add(new Element("Nitrogen", "N", 7, 7, 7));
        //elements.Add(new Element("Oxygen", "O", 8, 8, 8));
        //elements.Add(new Element("Fluorine", "F", 9, 9, 9));
        //elements.Add(new Element("Neon", "Ne", 10, 10, 10));

        //elements.Add(new Element("Sodium", "Na", 11, 12, 11));
        //elements.Add(new Element("Magnesium", "Hmg", 12, 12, 12));
        //elements.Add(new Element("Aluminium", "Al", 13, 14, 13));
        //elements.Add(new Element("Silicon", "Si", 14, 14, 14));
        //elements.Add(new Element("Phosphorus", "P", 15, 16, 15));
        //elements.Add(new Element("Sulfur", "S", 16, 16, 16));
        //elements.Add(new Element("Argon", "Ar", 19, 22, 19));
        //elements.Add(new Element("Potassium", "K", 19, 21, 19));
        //elements.Add(new Element("Calcium", "Ca", 20, 20, 20));
        //elements.Add(new Element("Scandium", "Sc", 21, 24, 21));

        //elements.Add(new Element("Titanium", "Ti", 22, 26, 22));
        //elements.Add(new Element("Vanadium", "V", 23, 28, 23));
        //elements.Add(new Element("Chromium", "Cr", 24, 28, 24));
        //elements.Add(new Element("Manganese", "Mn", 25, 30, 25));
        //elements.Add(new Element("Iron", "Fe", 26, 30, 26));
        //elements.Add(new Element("Cobalt", "Co", 27, 31, 27));
        //elements.Add(new Element("Nickel", "Ni", 28, 30, 28));
        //elements.Add(new Element("Copper", "Cu", 29, 35, 29));
        //elements.Add(new Element("Zinc", "Zn", 30, 35, 30));

        //elements.Add(new Element("Gallium", "Ga", 31, 39, 31));
        //elements.Add(new Element("Germanium", "Ge", 32, 41, 32));
        //elements.Add(new Element("Arsenic", "As", 33, 28, 42));
        //elements.Add(new Element("Selenium", "Se", 34, 45, 34));
        //elements.Add(new Element("Bromine", "Br", 35, 45, 35));
        //elements.Add(new Element("Krypton", "Kr", 36, 48, 36));
        //elements.Add(new Element("Rubidium ", "Rb", 37, 48, 37));
        //elements.Add(new Element("Strontium", "Sr", 38, 50, 38));
        //elements.Add(new Element("Yttrium", "Y", 39, 50, 39));


        spawnRandAtoms();
	}



    //Spawn numAtoms atoms as random elements
    void spawnRandAtoms()
    {
        for (int i = 0; i < numAtoms; i++)
        {
            GameObject newAtom = getRandomAtom();

            newAtom = Instantiate(newAtom, Random.onUnitSphere * spawnRadius, Random.rotation);
            newAtom.transform.GetChild(1).GetComponent<Renderer>().material.color = new Color((newAtom.GetComponent<AtomController>().atomicWeight * 2), 0, 0, 0.1f);
        }
    }



    //Return an element from list based by weight
    public Element getElement(int aWeight)
    {
        //Find the element with the matching weight
        foreach (Element element in elements)
        {
            if (element.weight == aWeight)
            {
                return element;
            }
        }
        //Default to last element if not found
        return elements[elements.Count-1];
    }

    //Return a randomly chosen element from list
    public Element getRandomElement()
    {
        return elements[Random.Range(1, 5)];
    }



    //Return an atom GameObject with appropriate element properties based on weight
    public GameObject getAtom(int weight)
    {
        //Grab prefab
        GameObject newAtom = prefab;
        //Get element
        Element element = getElement(weight);

        //Assign element's qualities to atom
        newAtom.GetComponent<AtomController>().setupAtom(element.elementName, element.symbol, element.numProtons, element.numNeutrons, element.numElectrons, element.atomColor);

        newAtom.name = "Atom";

        return newAtom;
    }

    //Return a random atom GameObject with a randomly chosen element's properties
    public GameObject getRandomAtom()
    {
        //Grab prefab
        GameObject newAtom = prefab;
        //Get a random element
        Element element = getRandomElement();

        //Assign element's qualities to atom
        newAtom.GetComponent<AtomController>().setupAtom(element.elementName, element.symbol, element.numProtons, element.numNeutrons, element.numElectrons, element.atomColor);

        newAtom.name = "Atom";

        return newAtom;
    }
}
