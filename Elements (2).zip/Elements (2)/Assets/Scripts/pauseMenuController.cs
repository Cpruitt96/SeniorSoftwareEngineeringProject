﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class pauseMenuController : MonoBehaviour {
	public GameObject pauseMenu;
	public bool isPaused;
	public GameObject player;


	void Start () {
		pauseMenu.SetActive (false);
		isPaused = false;
	}
	

	void Update () {
		if (Input.GetKeyDown (KeyCode.Escape)) {
			if (isPaused == false) {
                Cursor.visible = true;
                Time.timeScale = 0f;
				pauseMenu.SetActive (true);
				isPaused = true;
				player.GetComponent<PlayerController> ().playerState = PlayerController.PlayerState.PAUSED;
			}
			else if(isPaused == true){
                Cursor.visible = false;
                pauseMenu.SetActive (false);
				Time.timeScale = 1f;
				isPaused = false;
				player.GetComponent<PlayerController> ().playerState = PlayerController.PlayerState.TO_PLAY;
            }
		}
	}

	public void Play(){
		pauseMenu.SetActive (false);
		Time.timeScale = 1f;
		isPaused = false;
		player.GetComponent<PlayerController> ().playerState = PlayerController.PlayerState.TO_PLAY;
	}

    public void Restart()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    public void quitGame(){
		SceneManager.LoadScene ("MainMenu");
		Time.timeScale = 1f;
	}
}
