﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AtomController : MonoBehaviour {

    public enum AtomState { FORMING, ACTING, FUSING }
    public AtomState atomState; 

    //Atom Children GameObjects
    public GameObject nucleus;
    public float nucleusRadius;
    public GameObject electronCloud;
    public Color32 originalColor;

    //Element Data
    public string elementName;
    public string symbol;

    //Protons
    public int numProtons;
    private GameObject proton;

    //Neutrons
    public int numNeutrons;
    private GameObject neutron;

    //Electrons
    public int numElectrons;

    public int atomicWeight;

    //Bonding
    public float jointStrength;

    //Hierarchy
    public int maxBonds;
    public List<GameObject> bondedAtoms = new List<GameObject>();

    //States
    public bool isPlayer;
    public bool selected;

    //Resources
    public GameObject atomPrefab;
    public GameObject fissionEffect;
    public GameObject label;
	public  bool labelFlag = false;

    //Heat
    public float heat;
    private Rigidbody rb;

    private void Awake()
    {
		if (!(isPlayer)) {
			rb = GetComponent<Rigidbody> ();
		}
    }

    void Start () {
        HeatSystem.heat += heatUp;

        //Set States
        atomState = AtomState.FORMING;
        selected = false;

        //Load resources
        atomPrefab = Resources.Load("Atom") as GameObject;
        fissionEffect = Resources.Load("FissionEffect") as GameObject;

        //Set atomic weight
        atomicWeight = numProtons + numNeutrons;
        
        //Load prefabs
        proton = Resources.Load("Proton") as GameObject;
        neutron = Resources.Load("Neutron") as GameObject;

        //Set Label
        label = transform.GetChild(2).gameObject;

        //Set atom parts
        nucleus = transform.GetChild(0).gameObject;
        electronCloud = transform.GetChild(1).gameObject;

        generateParticles();
        setColor();

        enableLabel();
    }



    //Creates the nucleus of the atom
    void generateParticles()
    {
        //Destroy existing particles if they exist
        foreach (Transform child in nucleus.transform)
        {
            GameObject.Destroy(child.gameObject);
        }

        //Generate new particles
        //Generate protons
        for (int i = 0; i < numProtons; i++)
        {
            GameObject newProton = Instantiate(proton);
            newProton.transform.SetParent(transform.GetChild(0));
            newProton.transform.position = transform.position + Random.onUnitSphere * nucleusRadius;
        }
        //Generate Neutrons
        for (int i = 0; i < numNeutrons; i++)
        {
            GameObject newNeutron = Instantiate(neutron);
            newNeutron.transform.SetParent(transform.GetChild(0));
            newNeutron.transform.position = transform.position + Random.onUnitSphere * nucleusRadius;
        }
    }


    //Used as sort of a constructor in the spawning of atoms
    public void setupAtom(string aName, string aSymbol, int protons, int neutrons, int electrons, Color color)
    {
        elementName = aName;
        symbol = aSymbol;
        numProtons = protons;
        numNeutrons = neutrons;
        numElectrons = electrons;
        atomicWeight = numProtons + numNeutrons;
        originalColor = color;

        //Scaling***************************************************************************************************************************************************
        //nucleusRadius = (numProtons + numNeutrons) ;
        //electronCloud.transform.localScale = new Vector3(nucleusRadius+1, nucleusRadius+1, nucleusRadius+1);
    }


    //Sets the color of the atom
    public void setColor()
    {
        electronCloud.GetComponent<Renderer>().material.color = originalColor;
    }


    //Checks to see if bond is allowed. 
    public void tryBond(GameObject atom)
    {
        //BONDING RULES
        //Can't bond if atom weighs more than you (Gameplay)
        //Can't bond if all bondedAtom spaces are taken (bond # limit)        
        //Can't bond if atom is already in your molecule (prevents clumping)
        //Can't bond if the two atoms already bonded (prevents double and triple bonds on collision)
        // Debug.Log(bondedAtoms.Count + " " + maxBonds + " " + checkWeight(atom) + " " + !atom.GetComponent<AtomController>().isPlayer + " " + !isRelated(atom));
        if (checkWeight(atom) && (bondedAtoms.Count < maxBonds) && !isRelated(atom) && !bondedAtoms.Contains(atom))
        {
            bond(atom);
        }
    }


    //Bonds an atom to this atom
    public void bond(GameObject atom)
    {
        //The target atom's controller
        AtomController targetController = atom.GetComponent<AtomController>();

        // Debug.Log("Bond Started");
        //Add to bonds
        bondedAtoms.Add(atom);

        //Add this to target's bonds
        targetController.bondedAtoms.Add(gameObject);


        //"Molecule" - Empty Game Object - Parent of all atoms in molecule
        //If molecule doesn't exist
        if (transform.root.name != "Molecule" && transform.root.name != "Player Molecule")
        {
            startMolecule();
        }

        //Check if bonding atom is already in a molecule
        if (atom.transform.root.name == "Molecule")
        {
            absorbMolecule(atom.transform.root.gameObject);
        }
        else
        {
            //If bonding atom is solo, simply add it to the molecule
            atom.transform.SetParent(transform.root);
        }

        //Update Molecule weight
        transform.root.GetComponent<Molecule>().checkWeight();


        //If player bonds or is bonded with make all new atoms player
        if (isPlayer || targetController.isPlayer)
        {
            AtomController[] atoms = transform.root.GetComponentsInChildren<AtomController>();
            foreach (AtomController newAtom in atoms)
            {
                if (!newAtom.isPlayer)
                {
                    newAtom.isPlayer = true;
                }
            }
        }


        //Joint creation (_̲̅_̲̅_̲̅_̲̅_̲̅_̲̅_̲̅_̲̅_̲̅_̲̅_̲̅_̲̅_̲̅(M)~~~~~~~~~~~~~~~~~~ 

        //float jointStrength = (atom.GetComponent<AtomController>().atomicWeight + atomicWeight)*10;

        //This side
        SpringJoint myJoint = gameObject.AddComponent<SpringJoint>();
        myJoint.spring = 10000;
        //Give joint an appropriate break force based on each bonded atom***********************************************************************************************
        //myJoint.breakForce = jointStrength;
        myJoint.connectedBody = atom.GetComponent<Rigidbody>();
        myJoint.damper = 1000;
        myJoint.maxDistance = 0.1f;
        myJoint.anchor = new Vector3(0,0,0);
        myJoint.connectedAnchor = transform.InverseTransformPoint(atom.transform.position);

        //Target side
        SpringJoint targetsJoint = atom.AddComponent<SpringJoint>();
        targetsJoint.spring = 10000;
        //Give joint an appropriate break force based on each bonded atom
        //targetsJoint.breakForce = jointStrength;
        targetsJoint.connectedBody = GetComponent<Rigidbody>();
        targetsJoint.damper = 1000;
        targetsJoint.maxDistance = 0.1f;
        targetsJoint.anchor = new Vector3(0, 0, 0);
        targetsJoint.connectedAnchor = atom.transform.InverseTransformPoint(transform.position);


        //Updates the score if the player just bonded
        if (isPlayer)
        {
            ScoreTracker.instance.updateScore();
        }
    }


    //Removes joints and references between this atom and its bonded atoms
    public void unbond()
    {
        foreach (GameObject atom in bondedAtoms)
        {
            if (atom != null)
            {
                //Remove appropriate joints
                foreach (SpringJoint joint in atom.GetComponents<SpringJoint>())
                {
                    if (joint.connectedBody == gameObject)
                    {
                        if (joint != null)
                        {
                            Destroy(joint);
                        }
                    }
                }
                //Remove this from target's bondedAtoms
                atom.GetComponent<AtomController>().bondedAtoms.Remove(gameObject);
            }
        }
        //Clear this atoms bond list
        bondedAtoms.Clear();
        Destroy(gameObject);
    }



    private void OnJointBreak(float breakForce)
    {
        Debug.Log("Joint broke");
    }

    /*
    //Tells us a joint broke but not which one. An atom needs to be unbonded
    private void OnJointBreak(float breakForce)
    {
        //Gather the atoms still bonded through a joint
        List<GameObject> survivingBonds = new List<GameObject>();
        foreach (Joint joint in transform.GetComponents<Joint>())
        {
            survivingBonds.Add(joint.connectedBody.gameObject);
        }
        

        foreach (GameObject bond in bondedAtoms)
        {
            if (survivingJoints.Contains(bond))
            {

            }
        }
    }
    */


    //Returns true if the target atom is lighter than this atom
    public bool checkWeight(GameObject atom)
    {
        if (atom.GetComponent<AtomController>().atomicWeight <= atomicWeight)
        {
            return true;
        }
        else
        {
            return false;
        }
    }


    //Checks if target atom is in Molecule
    public bool isRelated(GameObject target)
    {
        //Check each atom in Molecule to see if it matches target
        for (int i = 0; i < transform.root.childCount; i++)
        {
            if (transform.root.GetChild(i) == target)
            {
                return true;
            }
        }
        return false;
    }



    //Begins a new molecule with this as its atom
    public void startMolecule()
    {
        //Create & Setup Molecule
        GameObject newMolecule = new GameObject();
        newMolecule.name = "Molecule";
        newMolecule.AddComponent<Molecule>();

        //Add this to it
        transform.parent = newMolecule.transform;
    }


    //Transfers a molecule's members to this atom's molecule and deletes the old shell
    public void absorbMolecule(GameObject molecule)
    {
        //Transfer member atoms
        int numChildren = molecule.transform.childCount;
        for (int i = 0; i < numChildren; i++)
        {
            molecule.transform.GetChild(0).transform.SetParent(transform.root);
        }

        if (molecule.transform.childCount == 0)
        {
            Destroy(molecule);
        }
        
    }



    //Fission on this atom
    public void fission()
    {
        if(numNeutrons + numProtons > 2 && gameObject.tag == "Atom")
        {
            //Remove color overlay
            electronCloud.GetComponent<Renderer>().material.color = originalColor;

            //Get new self
            Element newSelf = AtomGen.instance.getPreviousElement(this);

            //Get atom(s) to emit
            GameObject productAtom = AtomGen.instance.getAtom(1);

            //Instantiate product atom(s)
            for(int i = 0; i < atomicWeight-newSelf.weight; i++)
            {
                GameObject theAtom = Instantiate(productAtom, transform.position + Random.onUnitSphere, Quaternion.identity);
                //Make unbondable so it doesn't immediately bond
                StartCoroutine(theAtom.GetComponent<AtomController>().unbondable());
            }
           

            elementName = newSelf.elementName;
            symbol = newSelf.symbol;
            numNeutrons = newSelf.numNeutrons;
            numProtons = newSelf.numProtons;
            numElectrons = newSelf.numElectrons;
            atomicWeight = newSelf.weight;
            originalColor = newSelf.atomColor;
            generateParticles();
            setColor();
            updateLabel();


            //Effect
            GameObject theEffect = Instantiate(fissionEffect, transform.position, Quaternion.identity);
            Destroy(theEffect,1f);

            AtomGen.count += 1;

            //Launch out a few nuetrons?***********************************************************************

            //Player gains energy
            PlayerController.instance.modifyEnergy(productAtom.GetComponent<AtomController>().numNeutrons + productAtom.GetComponent<AtomController>().numProtons);

            //UPDATE JOINT STRENGTH******************************************************************************
        }
    }



    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Atom")
        {
            tryBond(collision.gameObject);
        }
		if (gameObject.tag == "Player") {	
			//Debug.Log ("player colision");

		}
    }


    private void OnMouseEnter()
    {
        if (PlayerController.instance.playerState == PlayerController.PlayerState.EDIT && isPlayer && !selected && gameObject.name == "Atom(Clone)")
        {
            electronCloud.GetComponent<Renderer>().material.color = Color.yellow;
        }
    }


    private void OnMouseExit()
    {
        //Check for edit mode, being player, and not being selected
        if (PlayerController.instance.playerState == PlayerController.PlayerState.EDIT && isPlayer && !selected && gameObject.name == "Atom(Clone)")
        {
            electronCloud.GetComponent<Renderer>().material.color = originalColor;
        }
    }


    private void OnMouseOver()
    {
        if (isPlayer)
        {
            //Fission
            if (Input.GetMouseButtonDown(1))
            {
                fission();
            }

            //Fusion
            if (Input.GetMouseButtonDown(0))
            {
                selected = PlayerController.instance.selectAtom(gameObject);
            }
        }
    }



    public IEnumerator unbondable()
    {
        GetComponent<Collider>().enabled = false;
        yield return new WaitForSeconds(.5f);
        GetComponent<Collider>().enabled = true;
    }

    void heatUp(float amount)
    {
		if (!(isPlayer)) {
			rb.AddForce (rb.velocity.normalized * amount, ForceMode.Impulse);
		}
    }

    //Enables the label
    public void enableLabel()
    {
        label.SetActive(true);
        label.transform.GetChild(0).GetComponent<Text>().text = (elementName + " | " + symbol  + "\n" + atomicWeight.ToString());
    }

    //Disables the label
    public void disableLabel()
    {
        label.SetActive(false);
    }

    //Updates the label
    public void updateLabel()
    {
        label.transform.GetChild(0).GetComponent<Text>().text = (elementName + " | " + symbol + "\n" + atomicWeight.ToString());
    }
}
